File VIPeR_partitions contains the sets of 316 pair images 
in VIPeR dataset used in our 10 experiments.
Format is:
n pair - name image cam_a    name image cam_b


Files iLIDS_gallerysets, ETHZ1_gallerysets, ETHZ2_gallerysets, ETHZ3_gallerysets
contain the sets of images in the gallery set in the single-shot case experiments. 
As for VIPer, we did 10 experiments for each dataset.
Format is:
n img - name_img